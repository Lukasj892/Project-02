# Exercise-02d-Menu-and-HUD

Exercise for MSCH-C220

A basic space-shooter arcade game, created in Godot.

## Implementation

Created using [Godot 3.5](https://godotengine.org/download)

Assets are provided by [Kenney.nl](https://kenney.nl/assets/space-shooter-extension), provided under a [CC0 1.0 Public Domain License](https://creativecommons.org/publicdomain/zero/1.0/).

The explosion spritesheet was released into the public domain by [StumpyStrust](https://opengameart.org/content/explosion-sheet)

The Hyperspace typeface was developed by [Pixel Sagas](https://www.dafont.com/hyperspace.font) and is freely available for personal use.

## References
None

## Future Development
Advanced features?

## Created by
Lukas Jackson
```
